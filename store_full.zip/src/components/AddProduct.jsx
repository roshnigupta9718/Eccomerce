import React from 'react'

function AddProduct() {
  return (
    <div className='border border-4 bg-success-subtle p-3 col-9'>

    </div>
  )
}

export default AddProduct